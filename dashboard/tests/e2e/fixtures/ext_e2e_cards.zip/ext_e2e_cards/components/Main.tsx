import React from "react";
import { AbsoluteFill } from "remotion";
export default () => <AbsoluteFill style={{ background: "#123" }} />;
